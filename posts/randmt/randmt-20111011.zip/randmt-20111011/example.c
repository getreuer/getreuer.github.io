#include <stdio.h>
#include "randmt.h"


int main(void)
{
    int i;

    /* Initialize the random number generator */
    init_randmt_auto();

    printf("20 values from rand_unif():\n");
    
    for(i = 0; i < 20; i++)
        printf("%10.8f\n", rand_unif());

    return 0;
}
