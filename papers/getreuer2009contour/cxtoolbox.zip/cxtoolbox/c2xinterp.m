function u = c2xinterp(v,rho)
%C2XINTERP  Factor-2 contour stencil image interpolation
%   U = C2XINTERP(V) interpolates V by factor 2 by the contour stencil
%   method as described in [1,2].  V may either be a grayscale image, an 
%   MxNx3 RGB image, or the filename of an image.
%   
%   C2XINTERP(V,RHO) specifies the smoothing parameter RHO (default 0.5).
%
%   [1] P. Getreuer, "Contour stencils for edge-adaptive image 
%       interpolation."  Proc. SPIE, vol. 7257, 2009.
%   [2] P. Getreuer, "Image zooming with contour stencils."  Proc. SPIE,
%       vol. 7246, 2009.

% Pascal Getreuer 2008-2009

if nargin < 2
    if nargin < 1
        error('Not enough input arguments.');
    end
    
    rho = 0.5;
end

if ischar(v)
    % Read image and convert to range [0,1]
    [v,Map] = imread(v);
    v = double(v);    
    
    if ~isempty(Map)
        % Convert indexed image to RGB
        Ind = v + 1;
        Ind(:,:,2) = v + (1 + size(Map,1));
        Ind(:,:,3) = v + (1 + 2*size(Map,1));
        v = double(Map(Ind));
    else        
        v = v/255;
    end
end

[N1,N2,N3] = size(v);
iu = [1,1:N1-1];
id = [2:N1,N1];
il = [1,1:N2-1];
ir = [2:N2,N2];

%%% Stencil Selection %%%
% For each cell, find the best-fitting stencil S^*
S = fitstencils(v,rho);

%%% Interpolate along the detected contours %%%
% Compute interpolation according to the best-fitting stencil.
S = S(:,:,ones(N3,1));
yn = (v + v(:,ir,:))/2;
yw = (v + v(id,:,:))/2;
ys = yn(id,:,:);
ye = yw(:,ir,:);
x = (ye + yw)/2;

tmp = (v + v(id,ir,:))/2;
i = (S == 3 | S == 5 | S == 9);
x(i) = tmp(i);

tmp = (v(id,:,:) + v(:,ir,:))/2;
i = (S == 4 | S == 7 | S == 11);
x(i) = tmp(i);

i = (S == 5 | S == 7);
ys(i) = x(i);
yn(i) = x(i);

i = (S == 9 | S == 11);
ye(i) = x(i);
yw(i) = x(i);

tmp = (v(:,ir,:) + v(id,ir,:))/2;
i = (S == 6);
yn(i) = tmp(i);
i = (S == 8);
ys(i) = tmp(i);

tmp = (v + v(id,:,:))/2;
i = (S == 6);
ys(i) = tmp(i);
i = (S == 8);
yn(i) = tmp(i);

tmp = (v(id,:,:) + v(id,ir,:))/2;
i = (S == 10);
yw(i) = tmp(i);
i = (S == 12);
ye(i) = tmp(i);

tmp = (v + v(:,ir,:))/2;
i = (S == 10);
ye(i) = tmp(i);
i = (S == 12);
yw(i) = tmp(i);

u = zeros(2*N1,2*N2,N3);
u(1:2:2*N1,1:2:2*N2,:) = v;
u(2:2:2*N1,2:2:2*N2,:) = x;
u(1:2:2*N1,2:2:2*N2,:) = (yn + ys(iu,:,:))/2;
u(2:2:2*N1,1:2:2*N2,:) = (yw + ye(:,il,:))/2;
u(1,2:2:2*N2,:) = yn(1,:,:);
u(2:2:2*N1,1,:) = yw(:,1,:);

% Show the result if no output was specified.
if nargout == 0
    if N3 == 3
        image(min(max(u,0),1));
    elseif N3 == 1
        image(u*255);
        colormap(gray(256));
    end

    axis image
    axis off
    clear u
end
