function u = c2xzoom(v,psfcoeff,eta,rho)
%C2XZOOM  Factor-2 contour stencil image zooming (deconvolution)
%   U = C2XZOOM(V) increases the resolution of image V by factor 2, where V
%   is either an MxN grayscale image or an MxNx3 RGB color image.  The
%   zoomed image U is of size 2Mx2N or 2Mx2Nx3.  Contour stencils are used
%   to construct a quadratic graph regularization adapted to the contours
%   of V, as described in [1].
%
%   U = C2XZOOM(V,PSFCOEFF,ETA,RHO) specifies additional method parameters:
%
%   PSFCOEFF specifies the point spread function (PSF).  The 2D PSF is the
%   tensor product of
%     H1 = 1 + PSFCOEFF(1) (z + z^-1) + PSFCOEFF(2) (z^2 + z^-2),
%   (default PSFCOEFF = [0.35,0]).
%
%   ETA specifies the cross-contour edge weight (default 0.25).
%
%   RHO specifies the contour stencil denoising parameter (default 0.5).
%
%   [1] P. Getreuer, "Image zooming with contour stencils."  Proc. SPIE,
%       vol. 7246, 2009.


% Pascal Getreuer 2008-2009

for input = 4:-1:nargin+1
    switch input
        case 2
            psfcoeff = [0.35,0];
        case 3
            eta = 0.25;
        case 4
            rho = 0.5;
        otherwise 
            error('Not enough input arguments.');
    end    
end

CGTol = 1e-6;
CGMaxIter = 100;

% Pad the image
v = v([1,1,1:end,end,end],[1,1,1:end,end,end],:);

[N1,N2,N3] = size(v);


%%% Construct Graph %%%

% Get best-fitting stencils
Stencil = fitstencils(v,rho);
Smap = [0,1,2,3,4,5,5,7,7,9,9,11,11];
Stencil = Smap(Stencil+1);

% Construct the graph Laplacian, L
A = [0,0]*[1;2*N1];  N = [0,1]*[1;2*N1];  C = [0,2]*[1;2*N1];
W = [1,0]*[1;2*N1];  X = [1,1]*[1;2*N1];  E = [1,2]*[1;2*N1];
B = [2,0]*[1;2*N1];  S = [2,1]*[1;2*N1];  D = [2,2]*[1;2*N1];

uNumel = 4*N1*N2;
maxnnz = 32*N1*N2;
Li = zeros(maxnnz,1);
Lj = zeros(maxnnz,1);
Lw = zeros(maxnnz,1);
m = 0;

for j = 1:N2
    for i = 1:N1
        k = 2*(i-1) + 2*(j-1)*(2*N1) + 1;

        % Add edges to the graph according to the best-fitting stencil
        switch Stencil(i,j)
            case 1
                edges = [A,N,1; N,C,1;         % stencil #1
                    W,X,1; X,E,1;
                    B,S,1; S,D,1;
                    A,W,eta; W,B,eta;
                    N,X,eta; X,S,eta;
                    C,E,eta; E,D,eta;];
            case 2
                edges = [A,W,1; W,B,1;         % stencil #2  |
                    N,X,1; X,S,1;
                    C,E,1; E,D,1;
                    A,N,eta; N,C,eta;
                    B,S,eta; S,D,eta;
                    W,X,eta; X,E,eta;];
            case 3
                edges = [W,S,1; N,E,1;         % stencil #3  \
                    A,X,1; X,D,1;
                    A,D,1;
                    A,W,eta; W,B,eta;
                    N,X,eta; X,S,eta;
                    C,E,eta; E,D,eta;
                    A,N,eta; N,C,eta;
                    W,X,eta; X,E,eta;
                    B,S,eta; S,D,eta];
            case 4
                edges = [W,N,1; S,E,1;         % stencil #4  /
                    B,X,1; X,C,1;
                    B,C,1;
                    A,W,eta; W,B,eta;
                    N,X,eta; X,S,eta;
                    C,E,eta; E,D,eta;
                    A,N,eta; N,C,eta;
                    W,X,eta; X,E,eta;
                    B,S,eta; S,D,eta];
            case 5
                edges = [A,W,eta; W,B,eta;     % stencil #5  2\
                    N,X,eta; X,S,eta;
                    C,E,eta; E,D,eta;
                    A,S,1; N,D,1;];
            case 7
                edges = [A,W,eta; W,B,eta;     % stencil #7  2/
                    N,X,eta; X,S,eta;
                    C,E,eta; E,D,eta;
                    B,N,1; S,C,1;];
            case 9
                edges = [A,N,eta; N,C,eta;     % stencil #9  \2
                    W,X,eta; X,E,eta;
                    B,S,eta; S,D,eta;
                    A,E,1; W,D,1;];
            case 11
                edges = [A,N,eta; N,C,eta;     % stencil #11 /2
                    W,X,eta; X,E,eta;
                    B,S,eta; S,D,eta;
                    W,C,1; B,E,1;];
            otherwise % (case 0)
                edges = [A,W,eta; W,B,eta;     % stencil #0  isotropic
                    N,X,eta; X,S,eta;
                    C,E,eta; E,D,eta;
                    A,N,eta; N,C,eta;
                    W,X,eta; X,E,eta;
                    B,S,eta; S,D,eta];
        end
        
        edges(:,1:2) = k + edges(:,1:2);
        n = find(edges(:,1) <= uNumel & edges(:,2) <= uNumel);
        Li(m+1:m+2*length(n)) = edges(n,[1,2]);
        Lj(m+1:m+2*length(n)) = edges(n,[2,1]);
        Lw(m+1:m+2*length(n)) = -edges(n,[3,3]);
        m = m + 2*length(n);
    end
end

Li = Li(1:m);
Lj = Lj(1:m);
Lw = Lw(1:m);
% Remove duplicate edges
L = sparse(Li,Lj,Lw);
[Li,Lj,Lw] = find(L);
[i1,i2] = ind2sub([2*N1,2*N2],Li);
Lisubs = [i1(:),i2(:)];


%%% Solve the minimization problem %%%

% Compute wavelet lifting coefficients
walpha = psfcoeff(2)/psfcoeff(1);
wbeta = psfcoeff(1)/(1 - 2*psfcoeff(2));
wdelta = -(1+2*walpha)/(2 + 4*wbeta + 8*walpha*wbeta);
wparams = [walpha,wbeta,wdelta];
Scale = (1 + 4*walpha*wbeta + 2*wbeta)^2;

% Solve linear system in the wavelet domain using conjugate gradients.
u = zeros(2*N1,2*N2,N3);

for Channel = 1:N3    
    % Compute initial residual, r = - tildeG* L tildeH v
    r = zeros(2*N1,2*N2);
    r(1:2:2*N1,1:2:2*N2) = v(:,:,Channel)*Scale;    
    r = invblurwavelet(r,wparams);
    r = accumarray(Lisubs,Lw.*(r(Li) - r(Lj)));
    r = -dualblurwavelet(r,wparams);
    r(1:2:2*N1,1:2:2*N2) = 0;
        
    wu = zeros(2*N1,2*N2);
    wu(1:2:2*N1,1:2:2*N2) = v(:,:,Channel)*Scale;
    p = r;
    e1 = norm(r(:))^2;

    % Conjugate gradient method
    for k = 1:CGMaxIter
        % Compute Ap = (tildeG* L tildeG) p
        Ap = invblurwavelet(p,wparams);
        Ap = accumarray(Lisubs,Lw.*(Ap(Li) - Ap(Lj)));
        Ap = dualblurwavelet(Ap,wparams);
        Ap(1:2:2*N1,1:2:2*N2) = 0;
        
        alpha = e1/(p(:)'*Ap(:));
        wu = wu + alpha*p;
        r = r - alpha*Ap;
        e2 = norm(r(:))^2;

        if e2 < CGTol^2
            break;
        end
        
        beta = e2/e1;
        p = r + beta*p;
        e1 = e2;
    end

    u(:,:,Channel) = wu;
end

u = invblurwavelet(u,wparams);   % Inverse wavelet transform
%u = u(3:end-2,3:end-2,:);        % Trim the padding
u = u(5:end-4,5:end-4,:);        % Trim the padding

% Show the result if no output was specified.
if nargout == 0
    if N3 == 3
        image(min(max(u,0),1));
    elseif N3 == 1
        image(u*255);
        colormap(gray(256));
    end
    
    axis image
    axis off
    clear u
end
return;

function x = invblurwavelet(x,mu)
% Inverse wavelet transform
[N1,N2,N3] = size(x); %#ok<NASGU>
x(2:2:N1,:,:) = x(2:2:N1,:,:) - mu(3)*(x([3:2:N1,N1-1],:,:) + x(1:2:N1,:,:));
x(1:2:N1,:,:) = x(1:2:N1,:,:) - mu(2)*(x(2:2:N1,:,:) + x([2,2:2:N1-2],:,:));
x(2:2:N1,:,:) = x(2:2:N1,:,:) - mu(1)*(x([3:2:N1,N1-1],:,:) + x(1:2:N1,:,:));
x(:,2:2:N2,:) = x(:,2:2:N2,:) - mu(3)*(x(:,[3:2:N2,N2-1],:) + x(:,1:2:N2,:));
x(:,1:2:N2,:) = x(:,1:2:N2,:) - mu(2)*(x(:,2:2:N2,:) + x(:,[2,2:2:N2-2],:));
x(:,2:2:N2,:) = x(:,2:2:N2,:) - mu(1)*(x(:,[3:2:N2,N2-1],:) + x(:,1:2:N2,:));
return;

function x = dualblurwavelet(x,mu)
% Dual wavelet transform
[N1,N2,N3] = size(x); %#ok<NASGU>
x(:,1:2:N2,:) = x(:,1:2:N2,:) - mu(1)*(x(:,2:2:N2,:) + x(:,[2,2:2:N2-2],:));
x(:,2:2:N2,:) = x(:,2:2:N2,:) - mu(2)*(x(:,[3:2:N2,N2-1],:) + x(:,1:2:N2,:));
x(:,1:2:N2,:) = x(:,1:2:N2,:) - mu(3)*(x(:,2:2:N2,:) + x(:,[2,2:2:N2-2],:));
x(1:2:N1,:,:) = x(1:2:N1,:,:) - mu(1)*(x(2:2:N1,:,:) + x([2,2:2:N1-2],:,:));
x(2:2:N1,:,:) = x(2:2:N1,:,:) - mu(2)*(x([3:2:N1,N1-1],:,:) + x(1:2:N1,:,:));
x(1:2:N1,:,:) = x(1:2:N1,:,:) - mu(3)*(x(2:2:N1,:,:) + x([2,2:2:N1-2],:,:));
return;
