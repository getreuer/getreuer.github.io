% Try this first!  Type "zoomdemo" to run.

% Pascal Getreuer 2009


close all

% Read image
v = imread('test.png');
v = double(v)/255;

figure(1);
image(v);          % Show input image
axis image
title('Input');

ubicubic = bicubic2x(v);
ubicubic = min(max(ubicubic,0),1);

figure(2);
image(ubicubic);   % Bicubic interpolation
axis image
title('Bicubic Interpolation');
drawnow;

tic;
% Compute contour stencil interpolation (see C2XINTERP for more details)
rho = 0.95;
uinterp = c2xinterp(v,rho);
tinterp = toc;

figure(3);
image(uinterp);   % Contour stencil interpolation
axis image
title(sprintf('Contour Stencil Interpolation (%.3fs)',tinterp));
drawnow;

% Compute contour stencil zooming (see C2XZOOM for more details)
psfcoeff = [0.25,0];
eta = 0.25;
tic;
uzoom = c2xzoom(v,psfcoeff,eta);
tzoom = toc;
uzoom = min(max(uzoom,0),1);

figure(4);
image(uzoom);     % Show zooming result
axis image
title(sprintf('Contour Stencil Zooming (%.3fs)',tzoom));
