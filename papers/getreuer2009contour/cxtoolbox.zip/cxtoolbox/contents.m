% Contour stencil interpolation, zooming, and enhancement functions.
% Version 1.0         16-Feb-2009
%
%   zoomdemo     - Try this first!  Type "zoomdemo" to run.
%
%   c2xinterp    - Factor-2 contour stencil image interpolation
%   c2xzoom      - Factor-2 contour stencil image zooming (deconvolution)
%   cenhance     - Contour stencil image enhancement
%   fitstencils  - Find the best-fitting contour stencils over an image
