function u = cenhance(f,maxiter,lambda,kappa,rho)
%CENHANCE  Contour stencil image enhancement
%   U = CENHANCE(F,MAXITER) applies MAXITER iterations of contour stencil
%   enhancement to image F as described in [1].  F may be a grayscale image
%   or an RGB color image.
%
%   U = CENHANCE(F,MAXITER,LAMBDA,KAPPA,RHO) specifies further parameters:
%
%   LAMBDA controls the balance between sharpening and denoising, larger
%   value implies more sharpening and less denoising (default 250).
%
%   KAPPA is the edge steepness in the soft sign, larger value implies
%   steeper edges (default 2).
%
%   RHO is the stencil denoising parameter (default 0.5);
%
%   [1] P. Getreuer, "Contour stencils for edge-adaptive image 
%       interpolation."  Proc. SPIE, vol. 7257, 2009.

for input = 5:-1:nargin+1
    switch input
        case 2
            maxiter = 5;
        case 3
            lambda = 250;
        case 4
            kappa = 2;
        case 5
            rho = 0.5;
        otherwise 
            error('Not enough input arguments.');
    end    
end

[N1,N2,N3] = size(f);
iu = [2,1:N1-1];
id = [2:N1,N1-1];
il = [2,1:N2-1];
ir = [2:N2,N2-1];
u = f;
TV = zeros(N1,N2,4);
u1 = zeros(N1,N2,N3);
u2 = zeros(N1,N2,N3);

n = ceil(2.5*rho);
% G = Gaussian with standard deviation rho
G = exp(-(-n:n).^2/(2*rho^2))/(sqrt(2*pi)*rho);
Gden = conv2(G,G,ones(N1,N2),'same');

% If f is a color image, convert from RGB to YUV.
if ndims(f) == 3    
    u(:,:,1) = 0.299*f(:,:,1) + 0.587*f(:,:,2) + 0.114*f(:,:,3);
    u(:,:,2) = -0.14713*f(:,:,1) - 0.28886*f(:,:,2) + 0.436*f(:,:,3);
    u(:,:,3) = 0.615*f(:,:,1) - 0.51499*f(:,:,2) - 0.10001*f(:,:,3);    
end

for iter = 1:maxiter
    Dv = sum(abs(u(id,:,:) - u),3);
    Dh = sum(abs(u(:,ir,:) - u),3);
    Da = sum(abs(u(id,ir,:) - u),3);
    Db = sum(abs(u(id,:,:) - u(:,ir,:)),3);
        
    TV(:,:,1) = (2*(Dh(:,il) + Dh) + Dh(id,il) ...
        + Dh(iu,il) + Dh(iu,:) + Dh(id,:))/8;
    TV(:,:,2) = (2*(Dv(iu,:) + Dv) + Dv(iu,il) ...
        + Dv(iu,ir) + Dv(:,il) + Dv(:,ir))/8;
    TV(:,:,3) = (2*(Da(iu,il) + Da) + Da(iu,:) + Da(:,il))/(6*sqrt(2));
    TV(:,:,4) = (Db(iu,il) + 2*(Db(iu,:) + Db(:,il)) + Db)/(6*sqrt(2));
    
    for k = 1:4
        TV(:,:,k) = conv2(G,G,TV(:,:,k),'same')./Gden;
    end
    
    [Mmin,smin] = min(TV,[],3);
    smin = smin(:,:,ones(N3,1));

    i = (smin == 1);
    tmp = u(iu,:,:);
    u1(i) = tmp(i);
    tmp = u(id,:,:);
    u2(i) = tmp(i);

    i = (smin == 2);
    tmp = u(:,il,:);
    u1(i) = tmp(i);
    tmp = u(:,ir,:);
    u2(i) = tmp(i);

    i = (smin == 3);
    tmp = (u(id,:,:) + u(:,il,:))/2;
    u1(i) = tmp(i);
    tmp = (u(iu,:,:) + u(:,ir,:))/2;
    u2(i) = tmp(i);

    i = (smin == 4);
    tmp = (u(iu,:,:) + u(:,il,:))/2;
    u1(i) = tmp(i);
    tmp = (u(id,:,:) + u(:,ir,:))/2;
    u2(i) = tmp(i);

    xi = (2/pi)*atan(kappa*( sum(abs(u - u1) - abs(u - u2),3) ));
    absxi = abs(xi);
    xi = (1 - sign(xi))/2;
    uxi = xi(:,:,ones(N3,1)).*u1 + (1 - xi(:,:,ones(N3,1))).*u2;

    w = 2./max(1e-12,sum(abs(u - u1) + abs(u - u2),3));
    w = w(:,:,ones(N3,1));
    wu = w(iu,:,:);
    wd = w(id,:,:);
    wl = w(:,il,:);
    wr = w(:,ir,:);

    utilde = (1 - absxi(:,:,ones(N3,1))).*u + absxi(:,:,ones(N3,1)).*uxi;
    u = (lambda*utilde + wu.*u(iu,:,:) + wd.*u(id,:,:) ...
        + wl.*u(:,il,:) + wr.*u(:,ir,:))...
        ./(lambda + wu + wd + wl + wr);
end

% If f is a color image, convert from YUV back to RGB.
if ndims(f) == 3
    f(:,:,1) = u(:,:,1) + 1.13983*u(:,:,3);
    f(:,:,2) = u(:,:,1) - 0.39465*u(:,:,2) - 0.5806*u(:,:,3);
    f(:,:,3) = u(:,:,1) + 2.03211*u(:,:,2);
    u = f;
end

% Show the result if no output was specified.
if nargout == 0
    if N3 == 3
        image(min(max(u,0),1));
    elseif N3 == 1
        image(u*255);
        colormap(gray(256));
    end
    
    axis image
    axis off
    clear u
end
