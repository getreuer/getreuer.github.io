function S = fitstencils(v,rho,w)
%FITSTENCILS  Find the best-fitting contour stencils over an image
%   S = FITSTENCILS(V) for an MxN grayscale image or an MxNx3 RGB color 
%   image V returns a map S of size MxN indicating the best-fitting stencil
%   for every cell.  For example S(1,1) is the best-fitting stencil on cell
%   V(1:2,1:2).
%
%   FITSTENCILS(V,RHO) specifies the denoising parameter RHO (default 0.5)
%   
%   FITSTENCILS(V,RHO,W) specifies the edge weights, where W is an array of
%   ten elements.

% Pascal Getreuer 2008-2009

for input = 3:-1:nargin+1
    switch input
        case 2
            rho = 0.5;
        case 3
            w = [2,1, 4,1, 2,2,1,1, 1,1];
        otherwise 
            error('Not enough input arguments.');
    end    
end

%%% Stencil Selection %%%
% For each cell, find the best-fitting stencil S^*
% with the minimum TV estimate

% Normalize stencil edge weights
w(1:2) = w(1:2)/(2*w(1) + 4*w(2));
w(3:4) = w(3:4)/(sqrt(2)*w(3) + 4*sqrt(2)*w(4));
w(5:8) = w(5:8)/(sqrt(2)*(w(5) + 2*w(8)) + 2*(w(6) + w(7)));
w(9:10) = w(9:10)/(2*(w(9) + sqrt(2)*w(10)));

[N1,N2,N3] = size(v);
TV = zeros(N1,N2,12);
iu = [1,1:N1-1];
id = [2:N1,N1];
il = [1,1:N2-1];
ir = [2:N2,N2];

% Precompute differences
if N3 == 3
    % For color images, the metric used is the L^1 norm in the
    % YCbCr colorspace,
    % norm = |Y1 - Y2| + |U1 - U2| + |V1 - V2|.
    yuv = 0.299*v(:,:,1) + 0.587*v(:,:,2) + 0.114*v(:,:,3);
    yuv(:,:,2) = -0.14713*v(:,:,1) - 0.28886*v(:,:,2) + 0.436*v(:,:,3);
    yuv(:,:,3) = 0.615*v(:,:,1) - 0.51499*v(:,:,2) - 0.10001*v(:,:,3);
    
    Dv = sum(abs(yuv(id,:,:) - yuv),3);
    Dh = sum(abs(yuv(:,ir,:) - yuv),3);
    Da = sum(abs(yuv(id,ir,:) - yuv),3);
    Db = sum(abs(yuv(id,:,:) - yuv(:,ir,:)),3);
else
    Dv = sum(abs(v(id,:,:) - v),3);
    Dh = sum(abs(v(:,ir,:) - v),3);
    Da = sum(abs(v(id,ir,:) - v),3);
    Db = sum(abs(v(id,:,:) - v(:,ir,:)),3);
end

% Measure along the horizontal stencil (index #1)
%      .   .
%   w2  w1  w2 
%  o---o---o---o
%             
%  o---o---o---o
%   w2  w1  w2
%      .   .
TV(:,:,1) = (Dh + Dh(id,:))*w(1) + ...
    (Dh(:,il) + Dh(:,ir) + Dh(id,il) + Dh(id,ir))*w(2);

% Measure along the vertical stencil (index #2)
%      o   o
%   w1 |   | w1
%  .   o   o   .
%   w2 |   | w2
%  .   o   o   .
%   w1 |   | w1
%      o   o
TV(:,:,2) = (Dv + Dv(:,ir))*w(1) + ...
    (Dv(iu,:) + Dv(id,:) + Dv(iu,ir) + Dv(id,ir))*w(2);

% Measure along the \ diagonal stencil (index #3)
%      o   .
%        \w4
%  o   o   o   .
%  w4\   \w3 \w4
%  .   o   o   o
%      w4\
%      .   o
TV(:,:,3) = Da*w(3) + (Da(:,il) + Da(iu,:) + Da(id,:) + Da(:,ir))*w(4);

% Measure along the / diagonal stencil (index #4)
%      .   o
%      w4/
%  .   o   o   o
%  w4/ w3/   /w4
%  o   o   o   .
%        /w4
%      o   .
TV(:,:,4) = Db*w(3) + (Db(:,il) + Db(iu,:) + Db(id,:) + Db(:,ir))*w(4);

% Measure along the 2\ A diagonal stencil (index #5)
%      o   o
%      |w6 | w7
%  o   o   o   .
% w8 \   \w5 \ w8
%  .   o   o   o
%   w7 |   |w6
%      o   o
TV(:,:,5) = Da*w(5) + (Dv(iu,:) + Dv(id,ir))*w(6) + ...
    (Dv(id,:) + Dv(iu,ir))*w(7) + (Da(:,il) + Da(:,ir))*w(8);

% Measure along the 2\ B diagonal stencil (index #6)
%      o   .
%        \ w10
%  .   o   o   .
%   w9 |   | w9
%  .   o   o   .
%    w10 \
%      .   o
TV(:,:,6) = (Dv + Dv(:,ir))*w(9) + (Da(iu,:) + Da(id,:))*w(10);

% Measure along the 2/ A diagonal stencil (index #7)
%      o   o
%   w7 | w6|
%  .   o   o   o
% w8 / w5/   / w8
%  o   o   o   .
%    w6|   | w7
%      o   o
TV(:,:,7) = Db*w(5) + (Dv(iu,ir) + Dv(id,:))*w(6) + ...
    (Dv(iu,:) + Dv(id,ir))*w(7) + (Db(:,il) + Db(:,ir))*w(8);

% Measure along the 2/ B diagonal stencil (index #8)
%      .   o
%    w10 /
%  .   o   o   .
%   w9 |   | w9
%  .   o   o   .
%        / w10
%      o   .
TV(:,:,8) = (Dv + Dv(:,ir))*w(9) + (Db(iu,:) + Db(id,:))*w(10);

% Measure along the \2 A diagonal stencil (index #9)
%      o   .
%   w6   \w8 w7
%  o---o   o---o
%   w7   \w5 w6
%  o---o   o---o
%        \w8
%      .   o
TV(:,:,9) = Da*w(5) + (Dh(:,il) + Dh(id,ir))*w(6) + ...
    (Dh(id,il) + Dh(:,ir))*w(7) + (Da(iu,:) + Da(id,:))*w(8);

% Measure along the \2 B diagonal stencil (index #10)
%      .   .
%       w9
%  o   o---o   .
% w10\       \w10
%  .   o---o   o
%       w9
%      .   .
TV(:,:,10) = (Dh + Dh(id,:))*w(9) + (Da(:,il) + Da(:,ir))*w(10);

% Measure along the /2 A diagonal stencil (index #11)
%      .   o
%   w7 w8/  w6
%  o---o   o---o
%   w6 w5/  w7
%  o---o   o---o
%      w8/
%      o   .
TV(:,:,11) = Db*w(5) + (Dh(:,ir) + Dh(id,il))*w(6) + ...
    (Dh(:,il) + Dh(id,ir))*w(7) + (Db(iu,:) + Db(id,:))*w(8);

% Measure along the /2 B diagonal stencil (index #12)
%      .   .
%       w9
%  .   o---o   o
% w10/       /w10
%  o   o---o   .
%       w9
%      .   .
TV(:,:,12) = (Dh + Dh(id,:))*w(9) + (Db(:,il) + Db(:,ir))*w(10);

%%% Stencil Denoising %%%
% Stencils are smoothed to reduce noise.
if rho > 0
    n = ceil(2.5*rho);
    % G = Gaussian with standard deviation rho
    G = exp(-(-n:n).^2/(2*rho^2))/(sqrt(2*pi)*rho);
    Gden = conv2(G,G,ones(N1,N2),'same');
        
    i5 = (TV(:,:,5) < TV(:,:,6));
    i7 = (TV(:,:,7) < TV(:,:,8));
    i9 = (TV(:,:,9) < TV(:,:,10));
    i11 = (TV(:,:,11) < TV(:,:,12));
    TV(:,:,5) = min(TV(:,:,5),TV(:,:,6));   
    TV(:,:,7) = min(TV(:,:,7),TV(:,:,8));
    TV(:,:,9) = min(TV(:,:,9),TV(:,:,10));
    TV(:,:,11) = min(TV(:,:,11),TV(:,:,12));
    
    for k = [1:4,5:2:12]
        TV(:,:,k) = conv2(G,G,TV(:,:,k),'same')./Gden;
    end
    
    TV(:,:,6:2:12) = TV(:,:,5:2:11);
    TV(find(i5) + N1*N2*5) = inf;
    TV(find(~i5) + N1*N2*4) = inf;
    TV(find(i7) + N1*N2*7) = inf;
    TV(find(~i7) + N1*N2*6) = inf;
    TV(find(i9) + N1*N2*9) = inf;
    TV(find(~i9) + N1*N2*8) = inf;
    TV(find(i11) + N1*N2*11) = inf;
    TV(find(~i11) + N1*N2*10) = inf;
end

% Select the best-fitting stencils
[TVmin,S] = min(TV,[],3);
S(sum(TV - TVmin(:,:,ones(12,1)) < 1e-4,3) > 1) = 0;
