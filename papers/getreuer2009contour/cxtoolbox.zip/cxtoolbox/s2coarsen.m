function v = s2coarsen(u)

[N1,N2,N3] = size(u);
v = wavelet('2d rspline 2.0',1,u,'sym');
v = v(1:N1/2,1:N2/2,:)/2;
