function u = bicubic2x(v)
%BICUBIC2X  Factor-2 bicubic image interpolation
%   U = BICUBIC2X(V) interpolates image V by factor 2 using bicubic
%   interpolation.  (Image Processing Toolbox is not required.)

% Pascal Getreuer 2009

[N1,N2,N3] = size(v);
u = zeros(2*N1,2*N2,N3);
u(1:2:2*N1,1:2:2*N2,:) = v;
u(2:2:2*N1,1:2:2*N2,:) = (9/16)*(v + v([2:N1,N1],:,:)) ...
    - (1/16)*(v([1,1:N1-1],:,:) + v([3:N1,N1,N1],:,:));
u(:,2:2:2*N2,:) = (9/16)*(u(:,[1:2:2*N2],:) + u(:,[3:2:2*N2,2*N2-1],:)) ...
    - (1/16)*(u(:,[1,1:2:2*N2-3],:) + u(:,[5:2:2*N2,2*N2-1,2*N2-1],:));

if nargout == 0
    if N3 == 3
        image(min(max(u,0),1));
    elseif N3 == 1
        image(u*255);
        colormap(gray(256));
    end
    
    axis image
    axis off    
    clear u
end
