/* Factor-2 contour stencil interpolation
   Pascal Getreuer 2008-2009
   
 Permission to use, copy, or modify c2xinterp.cpp and its documentation
 for educational and research purposes only and without fee is hereby
 granted, provided that this copyright notice and the original author's
 name appear on all copies and supporting documentation. This software
 shall not be used, rewritten, or adapted as the basis of a commercial
 software or hardware product without first obtaining permission of the
 author. The author makes no representations about the suitability of
 this software for any purpose. It is provided "as is" without express
 or implied warranty.
*/
#ifndef __C2XINTERP_H
#define __C2XINTERP_H

#include <inttypes.h>

void C2xInterp_RGBA(const uint32_t *wpSrc, 
	int iSrcWidth, int iSrcHeight, int iSrcStride,
	uint32_t *wpDest, int iDestStride);
	
#endif
