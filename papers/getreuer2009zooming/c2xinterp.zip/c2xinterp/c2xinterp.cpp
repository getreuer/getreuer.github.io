/* Factor-2 contour stencil interpolation
   Pascal Getreuer 2008-2009
   
 Permission to use, copy, or modify c2xinterp.cpp and its documentation
 for educational and research purposes only and without fee is hereby
 granted, provided that this copyright notice and the original author's
 name appear on all copies and supporting documentation. This software
 shall not be used, rewritten, or adapted as the basis of a commercial
 software or hardware product without first obtaining permission of the
 author. The author makes no representations about the suitability of
 this software for any purpose. It is provided "as is" without express
 or implied warranty.
*/
#include "c2xinterp.h"

/* Stencil edge weights */
#define W1	43
#define W2	22

#define W3	59
#define W4	16

#define W5	34
#define W6	22
#define W7	17

#define W8	39
#define W9	34

#define ABS(x) 		((x>=0)?(x):(-x))


/* Compute color distance as the L1-norm in YUV space */
int ColorDist(uint32_t A, uint32_t B)
{
	int iDistR = ( ((int)A & 0xFF) - ((int)B & 0xFF) );
	int iDistG  = ( ((int)A & 0xFF00) - ((int)B & 0xFF00) )>>8;
	int iDistB = ( ((int)A & 0xFF0000) - ((int)B & 0xFF0000) )>>16;
	register int iDistY = 4*(2*iDistR + 4*iDistG + iDistB);
	register int iDistU = -iDistR - 2*iDistG + 3*iDistB;
	register int iDistV = 4*iDistR - 3*iDistG - iDistB;
	
	return ABS(iDistY) + ABS(iDistU) + ABS(iDistV);
}

/* Average two 32-bit RGBA pixels */
inline uint32_t ColorAverage(uint32_t wA, uint32_t wB)
{
	return (((wA ^ wB) & 0xFEFEFEFE) >> 1) + (wA & wB);
}

/* Factor-2 contour stencil interpolation for 32-bit RGBA data
  wpSrc        Pointer to the source image data in RGBA format
  iSrcWidth    Source width in pixels
  iSrcHeight   Source height in pixels
  iSrcStride   Souce stride (pitch) between successive scanlines
  wpDest       Pointer to where to store the interpolated image
  iDestStride  Destination stride
*/
void C2xInterp_RGBA(const uint32_t *wpSrc, int iSrcWidth, int iSrcHeight, int iSrcStride,
		uint32_t *wpDest, int iDestStride)
{
	int Dh[2][3];
	int Dv[3][2];
	int Da[3][3];
	int Db[3][3];
	
	long int TV[12];
	long int TVmin;
	
	int tmp;
	int iDestWidth = 2*iSrcWidth;
	int iSrcJump = (iSrcStride>=iSrcWidth)?(iSrcStride - iSrcWidth):0;
	int iDestJump = (iDestStride>=iDestWidth)?(2*iDestStride - iDestWidth):iDestWidth;
	uint32_t a,b,c,d,x,yn,ys,ye,yw,yelast = 0;
	
	int m,n;
	int S;
	int k;
	int nj[4];
	
	
	for(n = 0; n < iSrcHeight; n++, wpSrc+=iSrcJump, wpDest+=iDestJump)
	{
		nj[0] = (n>0)?(-1):0;
		nj[1] = 0;
		nj[2] = (n<iSrcHeight-1)?(1):(0);
		nj[3] = (n<iSrcHeight-2)?(2):(iSrcHeight-1-n);
		
		Dh[0][0] = 0;
		Dh[1][0] = 0;
		
		a = wpSrc[0+nj[0]*iSrcStride];
		c = wpSrc[1+nj[0]*iSrcStride];
		yn = wpSrc[2+nj[0]*iSrcStride];
		b = wpSrc[0+nj[1]*iSrcStride];
		d = wpSrc[1+nj[1]*iSrcStride];
		ys = wpSrc[2+nj[1]*iSrcStride];
			
		Dv[0][0] = ColorDist(a,b);
		Da[0][1] = ColorDist(a,d);
		Db[0][1] = ColorDist(b,c);
		Dv[0][1] = ColorDist(c,d);
		Da[0][2] = ColorDist(c,ys);
		Db[0][2] = ColorDist(d,yn);

		Dh[0][1] = ColorDist(b,d);
		Dh[0][2] = ColorDist(d,ys);

		a = wpSrc[0+nj[2]*iSrcStride];
		c = wpSrc[1+nj[2]*iSrcStride];
		yn = wpSrc[2+nj[2]*iSrcStride];
			
		Dv[1][0] = ColorDist(a,b);
		Db[1][1] = ColorDist(a,d);
		Da[1][1] = ColorDist(b,c);
		Dv[1][1] = ColorDist(c,d);
		Db[1][2] = ColorDist(c,ys);
		Da[1][2] = ColorDist(d,yn);

		Dh[1][1] = ColorDist(a,c);
		Dh[1][2] = ColorDist(c,yn);

		b = wpSrc[0+nj[3]*iSrcStride];
		d = wpSrc[1+nj[3]*iSrcStride];
		ys = wpSrc[2+nj[3]*iSrcStride];
			
		Dv[2][0] = ColorDist(a,b);
		Da[2][1] = ColorDist(a,d);
		Db[2][1] = ColorDist(b,c);
		Dv[2][1] = ColorDist(c,d);
		Da[2][2] = ColorDist(c,ys);
		Db[2][2] = ColorDist(d,yn);
		
		Dv[0][0] = Dv[0][1];
		Dv[1][0] = Dv[1][1];
		Da[0][0] = Db[0][1];
		Da[1][0] = Db[1][1];
		Da[2][0] = Db[2][1];
		Db[0][0] = Da[0][1];
		Db[1][0] = Da[1][1];
		Db[2][0] = Da[2][1];
		
		a = wpSrc[0];
		c = wpSrc[1];
		
		if(n < iSrcHeight-1)
		{
			b = wpSrc[iSrcStride];
			d = wpSrc[iSrcStride+1];
		}
		else
		{
			b = a;
			d = c;
		}
			
		for(m = 0; m < iSrcWidth; m++, wpSrc++, wpDest+=2)
		{
			/* Measure along the horizontal stencil (index #0)
			        .   .   
			     
			    o---o---o---o
			           
			    o---o---o---o
			   
			        .   .
			*/
			TV[0] = (Dh[0][1] + Dh[1][1])*W1 + (Dh[0][0] + Dh[0][2] + Dh[1][0] + Dh[1][2])*W2;
			
			/* Measure along the vertical stencil (index #1)
			        o   o
			        |   |
			    .   o   o   .
			        |   |
			    .   o   o   .
			        |   |
			        o   o
			*/
			TV[1] = (Dv[1][0] + Dv[1][1])*W1 + (Dv[0][0] + Dv[2][0] + Dv[0][1] + Dv[2][1])*W2;
			
			/* Measure along the \ diagonal stencil (index #2)
			        o   .   
			          \
			    o   o   o   .
			      \   \   \
			    .   o   o   o
			          \
			        .   o
			*/
			TV[2] = Da[1][1]*W3 + (Da[0][1] + Da[1][2] + Da[1][0] + Da[2][1])*W4;
			
			/* Measure along the / diagonal stencil (index #3)
			        .   o   
			          /
			    .   o   o   o
			      /   /   /
			    o   o   o   .
			          /
			        o   .
			*/
			TV[3] = Db[1][1]*W3 + (Db[0][1] + Db[1][2] + Db[1][0] + Db[2][1])*W4;
			
			/* Measure along the 2\ A diagonal stencil (index #4)
			        o   o   
			        |   |
			    o   o   o   .
			      \   \   \
			    .   o   o   o
			        |   |
			        o   o
			*/
			TV[4] = Da[1][1]*W5 + (Dv[0][0] + Dv[2][1])*W6 + (Dv[0][1] + Dv[2][0] + Da[1][0] + Da[1][2])*W7;
			
			/* Measure along the 2/ A diagonal stencil (index #6)
			        o   o   
			        |   |
			    .   o   o   o
			      /   /   /
			    o   o   o   .
			        |   |
			        o   o
			*/
			TV[6] = Db[1][1]*W5 + (Dv[0][1] + Dv[2][0])*W6 + (Dv[0][0] + Dv[2][1] + Db[1][0] + Db[1][2])*W7;
			
			/* Measure along the \2 A diagonal stencil (index #8)
			        o   .   
			          \ 
			    o---o   o---o
			          \   
			    o---o   o---o
			          \ 
			        .   o
			*/
			TV[8] = Da[1][1]*W5 + (Dh[0][0] + Dh[1][2])*W6 + (Dh[0][2] + Dh[1][0] + Da[0][1] + Da[2][1])*W7;
			
			/* Measure along the /2 A diagonal stencil (index #10)
			        .   o   
			          / 
			    o---o   o---o
			          /   
			    o---o   o---o
			          / 
			        o   .
			*/
			TV[10] = Db[1][1]*W5 + (Dh[0][2] + Dh[1][0])*W6 + (Dh[0][0] + Dh[1][2] + Db[0][1] + Db[2][1])*W7;

			tmp = Dv[1][1] + Dv[1][0];
			/* Measure along the 2\ B diagonal stencil (index #5)
			        o   .   
			          \  
			    .   o   o   .
			        |   |  
			    .   o   o   .
			          \  
			        .   o
			*/
			TV[5] = tmp*W8 + (Da[0][1] + Da[2][1])*W9;
			/* Measure along the 2/ B diagonal stencil (index #7)
			        .   o   
			          /  
			    .   o   o   .
			        |   |  
			    .   o   o   .
			          /  
			        o   .
			*/
			TV[7] = tmp*W8 + (Db[0][1] + Db[2][1])*W9;

			tmp = Dh[1][1] + Dh[0][1];
			/* Measure along the \2 B diagonal stencil (index #9)
			        .   .
			            
			    o   o---o   .
			      \       \ 
			    .   o---o   o
			            
			        .   .
			*/
			TV[9] = tmp*W8 + (Da[1][0] + Da[1][2])*W9;
			/* Measure along the /2 B diagonal stencil (index #11)
			        .   .
			            
			    .   o---o   o
			      /       /
			    o   o---o   .
			            
			        .   .
			*/
			TV[11] = tmp*W8 + (Db[1][0] + Db[1][2])*W9;
			
			/* Select the best-fitting stencil */
			TVmin = TV[0];
			S = 0;
			
			for(k = 1;k < 12;k++)
			{
				if(TV[k] <= TVmin)
				{
					if(TV[k] < TVmin)
					{
						TVmin = TV[k];
						S = k;
					}
					else
						S = 0;
				}
			}
			
			/* The corners of the current cell are a,b,c,d and interpolated
			   values are yn,ys,yw,ye,x:
			     a    yn   c
			 
			     yw   x    ye
			     
			     b    ys   d
			*/
			
			switch(S)
			{
				case 2: /* Diagonal \   */
					yn = ColorAverage(a,c);
					ys = ColorAverage(b,d);
					yw = ColorAverage(a,b);
					ye = ColorAverage(c,d);
					x = ColorAverage(a,d);
					break;
				case 3: /* Diagonal /   */
					yn = ColorAverage(a,c);
					ys = ColorAverage(b,d);
					yw = ColorAverage(a,b);
					ye = ColorAverage(c,d);
					x = ColorAverage(b,c);
					break;
				case 4: /* Diagonal 2\ A   */
					yw = ColorAverage(a,b);
					ye = ColorAverage(c,d);
					ys = yn = x = ColorAverage(a,d);
					break;
				case 5: /* Diagonal 2\ B   */
					ys = yw = ColorAverage(a,b);
					yn = ye = ColorAverage(c,d);
					x = ColorAverage(ye,yw);
					break;
				case 6: /* Diagonal 2/ A   */
					yw = ColorAverage(a,b);
					ye = ColorAverage(c,d);
					ys = yn = x = ColorAverage(b,c);
					break;
				case 7: /* Diagonal 2/ B   */
					yn = yw = ColorAverage(a,b);
					ys = ye = ColorAverage(c,d);
					x = ColorAverage(ye,yw);
					break;
				case 8: /* Diagonal \2 A   */
					yn = ColorAverage(a,c);
					ys = ColorAverage(b,d);
					yw = ye = x = ColorAverage(a,d);
					break;
				case 9: /* Diagonal \2 B   */
					ye = yn = ColorAverage(a,c);
					yw = ys = ColorAverage(b,d);
					x = ColorAverage(yn,ys);
					break;
				case 10:/* Diagonal /2 A   */
					yn = ColorAverage(a,c);
					ys = ColorAverage(b,d);
					yw = ye = x = ColorAverage(b,c);
					break;
				case 11:/* Diagonal /2 B   */
					yw = yn = ColorAverage(a,c);
					ye = ys = ColorAverage(b,d);
					x = ColorAverage(yn,ys);
					break;
				default:/* Horizontal, vertical, or isotropic (cases 0 and 1)   */
					yn = ColorAverage(a,c);
					ys = ColorAverage(b,d);
					yw = ColorAverage(a,b);
					ye = ColorAverage(c,d);
					x = ColorAverage(yn,ys);
					break;
			}
			
			/* Dest(2*m,2*n) */
			wpDest[0] = a;
			
			/* Dest(2*m+1,2*n) */
			if(n > 0)
				wpDest[1] = ColorAverage(wpDest[1],yn);
			else
				wpDest[1] = yn;
			
			/* Dest(2*m,2*n+1) */
			if(m > 0)
				wpDest[iDestStride] = ColorAverage(yelast,yw);
			else
				wpDest[iDestStride] = yw;
			
			yelast = ye;
			
			/* Dest(2*m+1,2*n+1) */
			wpDest[iDestStride+1] = x;
			
			/* Dest(2*m+1,2*n+2) */
			if(n < iSrcHeight-1)
				wpDest[2*iDestStride+1] = ys;
					
			
			/* Shift window */
			a = c;
			b = d;
			
			Dh[0][0] = Dh[0][1];
			Dh[1][0] = Dh[1][1];
			Dh[0][1] = Dh[0][2];
			Dh[1][1] = Dh[1][2];
			
			Dv[0][0] = Dv[0][1];
			Dv[1][0] = Dv[1][1];
			Dv[2][0] = Dv[2][1];
			
			Da[0][0] = Da[0][1];
			Da[1][0] = Da[1][1];
			Da[2][0] = Da[2][1];
			
			Da[0][1] = Da[0][2];
			Da[1][1] = Da[1][2];
			Da[2][1] = Da[2][2];
			
			Db[0][0] = Db[0][1];
			Db[1][0] = Db[1][1];
			Db[2][0] = Db[2][1];
			
			Db[0][1] = Db[0][2];
			Db[1][1] = Db[1][2];
			Db[2][1] = Db[2][2];
			
			
			if(m < iSrcWidth-2)
			{
				c = wpSrc[2];
				yn = wpSrc[3];
				
				/* Compute differences for the new rightmost column in the window */
				
				Dh[0][2] = ColorDist(c,yn);
				
				if(n < iSrcHeight-1)
				{
					d = wpSrc[iSrcStride+2];
					ys = wpSrc[iSrcStride+3];
					
					if(n < iSrcHeight-2)
					{
						yw = wpSrc[2*iSrcStride+2];
						Dv[2][1] = ColorDist(d,yw);
						Da[2][2] = ColorDist(d,wpSrc[2*iSrcStride+3]);
						Db[2][2] = ColorDist(yw,ys);
					}
					
					Dh[1][2] = ColorDist(d,ys);
					Dv[1][1] = ColorDist(c,d);
					Da[1][2] = ColorDist(c,ys);
					Db[1][2] = ColorDist(d,yn);
				}
				else
					d = c;

				if(n > 0)
				{
					yw = *(wpSrc+(2-iSrcStride));
					Dv[0][1] = ColorDist(c,yw);
					Da[0][2] = ColorDist(yw,yn);
					Db[0][2] = ColorDist(c,*(wpSrc+(2-iSrcStride)+1));
				}
				else
				{
					Dv[0][1] = 0;
					Da[0][2] = Db[1][2];
					Db[0][2] = Da[1][2];
				}
			}
			else
			{
				Dh[0][2] = 0;
				Dh[1][2] = 0;
				
				Dv[0][1] = 0;
				Dv[1][1] = 0;
				Dv[2][1] = 0;
				
				Da[0][2] = 0;
				Da[1][2] = 0;
				Da[2][2] = 0;
				
				Db[0][2] = 0;
				Db[1][2] = 0;
				Db[2][2] = 0;
			}
		}
	}
}
