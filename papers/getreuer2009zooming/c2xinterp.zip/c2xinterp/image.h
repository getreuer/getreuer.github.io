/* CImage: A simple image class and interface to libpng
   Pascal Getreuer 2008-2009
*/
#ifndef __IMAGE_H
#define __IMAGE_H

#include <inttypes.h>
#include <png.h>

class CImage
{
	public:
		uint32_t *m_wpData;
		unsigned m_wWidth;
		unsigned m_wHeight;
		unsigned m_wNumEl;
	
		inline CImage():m_wpData(0),m_wWidth(0),m_wHeight(0),m_wNumEl(0){}
		inline ~CImage()
		{
			if(m_wpData)
				delete [] m_wpData;
		}
		inline unsigned Width() const{return m_wWidth;}
		inline unsigned Height() const{return m_wHeight;}
		inline unsigned NumEl() const{return m_wNumEl;}
		int Alloc(unsigned wNewWidth, unsigned wNewHeight);
};

int ReadPNG(const char *cpPath, CImage &Image);
int WritePNG(const char *cpPath, const CImage &Image);

#endif
