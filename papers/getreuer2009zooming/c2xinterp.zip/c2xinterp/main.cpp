/* Driver program, see readme.html for details.
   Pascal Getreuer 2008-2009
*/
#include <stdio.h>
#include "image.h"
#include "c2xinterp.h"


void PrintHelp();

int main(int argc, char *argv[])
{
	CImage Input, Output;
	int w,h,stride;
	
	
	if(argc == 1 || (argc == 2 && !strcmp(argv[1],"--help")) )
	{
		PrintHelp();
		return 0;
	}

	if(ReadPNG(argv[1],Input))  // Try to open the input file
	{
		printf("Unable to open input file, \"%s\".\n",argv[1]);
      	return 1;
	}

	printf("Input: %dx%d\n",Input.Width(),Input.Height());
	
	// Allocate memory for the interpolated image
	Output.Alloc(2*Input.Width(),2*Input.Height());
	
	// Compute contour stencil interpolation by calling C2xInterp_RGBA
	w = Input.Width();
	h = Input.Height();
	stride = w;
	C2xInterp_RGBA(Input.m_wpData,w,h,stride,Output.m_wpData,2*w);
	
	printf("Output: %dx%d\n",Output.Width(),Output.Height());
	
	// Write output file
	WritePNG((argc < 3)?"out.png":argv[2],Output);
	
	return 0;
}

// Print the usage instructions
void PrintHelp()
{
   printf("Factor-2 Contour Stencil Interpolation\n\
Pascal Getreuer 2009\n\n\
Usage: c2xinterp in.png [out.png]\n\
where \"in.png\" a PNG file.\n\n");
}
