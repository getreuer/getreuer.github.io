/* CImage: A simple image class and interface to libpng
   Pascal Getreuer 2008-2009
*/
#include "image.h"

// Allocate or reallocate a CImage object with specified size
int CImage::Alloc(unsigned wNewWidth, unsigned wNewHeight)
{
	if(m_wpData)
		delete [] m_wpData;
    
	m_wWidth = wNewWidth;
	m_wHeight = wNewHeight;
	m_wNumEl = m_wWidth*m_wHeight;
	m_wpData = new uint32_t[m_wNumEl];
		
	if(m_wpData == 0)
	{
		m_wWidth = 0;
		m_wHeight = 0;
		m_wNumEl = 0;
		return -1;
	}
		
	return 0;
}

// Use libpng to read a PNG file in 32-bit RGBA format
int ReadPNG(const char *cpPath, CImage &Image)
{
	FILE *fp;
	png_byte header[4];
	png_structp PngPtr;
	png_infop InfoPtr;
	png_uint_32 wWidth, wHeight;
	int iBitDepth, iColorType, iInterlaceType;
	unsigned j;
		
	// Open the file and check that it is a PNG file
	if(!(fp = fopen(cpPath, "rb"))
			|| fread(header, 1, 4, fp) != 4
			|| png_sig_cmp(header, 0, 4))
		return -1;
	
	// Read the info header
	if(!(PngPtr = png_create_read_struct(PNG_LIBPNG_VER_STRING,
		 NULL, NULL, NULL))
			|| !(InfoPtr = png_create_info_struct(PngPtr)))
	{
		if(PngPtr)
			png_destroy_read_struct(&PngPtr, png_infopp_NULL, png_infopp_NULL);
		
		fclose(fp);
		return -1;
	}
		
	if(setjmp(png_jmpbuf(PngPtr)))
	{
		png_destroy_read_struct(&PngPtr, &InfoPtr, png_infopp_NULL);
		fclose(fp);
		return -1;
	}
	
	png_init_io(PngPtr, fp);
	png_set_sig_bytes(PngPtr, 4);
	png_read_info(PngPtr, InfoPtr);
	png_get_IHDR(PngPtr, InfoPtr, &wWidth, &wHeight, &iBitDepth, &iColorType,
				 &iInterlaceType, int_p_NULL, int_p_NULL);

	// Convert 1-,2-,4-, or 16-bit data to 8-bit
	png_set_strip_16(PngPtr); 
	
	if (iColorType == PNG_COLOR_TYPE_PALETTE)
		png_set_palette_to_rgb(PngPtr);
	
	if (iColorType == PNG_COLOR_TYPE_GRAY && iBitDepth < 8)
		png_set_gray_1_2_4_to_8(PngPtr);

	if (png_get_valid(PngPtr, InfoPtr, PNG_INFO_tRNS))
		png_set_tRNS_to_alpha(PngPtr);
	
	// Convert gray to RGB
	if(iColorType == PNG_COLOR_TYPE_GRAY || iColorType ==
		  PNG_COLOR_TYPE_GRAY_ALPHA)
		png_set_gray_to_rgb(PngPtr);
	
	// Convert RGB to RGBA
	png_set_filler(PngPtr, 0xFF, PNG_FILLER_AFTER);

	png_set_interlace_handling(PngPtr);
	png_read_update_info(PngPtr, InfoPtr);
	
	// Allocate image memory and read the image
	Image.Alloc(wWidth,wHeight);
	png_bytep RowPtrs[wHeight];
	
	for (j = 0; j < wHeight; j++)
		RowPtrs[j] = (png_bytep)(Image.m_wpData + wWidth*j);
	
	png_read_image(PngPtr, RowPtrs);	
	
	// Done reading the file
	png_destroy_read_struct(&PngPtr, &InfoPtr, png_infopp_NULL);
	fclose(fp);
	
	return 0;
}

// Use libpng to write a 32-bit RGBA image as a PNG file
int WritePNG(const char *cpPath, const CImage &Image)
{
	FILE *fp;
	png_structp PngPtr;
	png_infop InfoPtr;
	png_bytep RowPtrs[Image.Height()];
	unsigned j;
   

   // Open the file
	if(!(fp = fopen(cpPath, "wb")))
		return -1;
     
	if(!(PngPtr = png_create_write_struct(PNG_LIBPNG_VER_STRING,
		 NULL, NULL, NULL))
			|| !(InfoPtr = png_create_info_struct(PngPtr)))
	{
		fclose(fp);

		if(PngPtr)
			png_destroy_write_struct(&PngPtr,  png_infopp_NULL);
      
		return -1;
	}
      
	if (setjmp(png_jmpbuf(PngPtr)))
	{
		fclose(fp);
		png_destroy_write_struct(&PngPtr, &InfoPtr);
		return -1;
	}

   // Configure output for 8-bit RGB color data
	png_init_io(PngPtr, fp);
	png_set_IHDR(PngPtr, InfoPtr, Image.Width(), Image.Height(), 8,
				 PNG_COLOR_TYPE_RGB_ALPHA,
				 PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_BASE,
				 PNG_FILTER_TYPE_BASE);
	png_write_info(PngPtr, InfoPtr);      

	for(j = 0; j < Image.Height(); j++)
		RowPtrs[j] = (png_bytep)(Image.m_wpData + Image.Width()*j);

   // Write the file
	png_write_image(PngPtr, RowPtrs);
	png_write_end(PngPtr, InfoPtr);
	fclose(fp);

	return 0;
}
